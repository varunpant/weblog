package com.example;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.text.StaticLayout;
import android.util.Log;


public class Chaser {
    private static final String TAG = MainPanel.class.getSimpleName();

    public Chaser() {
        this.xm = 0.0;
        this.ym = 0.0;

    }

    private double xm;
    private double ym;

    private double ox;
    private double oy;
    private double nw;
    private double nh;
    private double dp;


    private double px = ox;
    private double py = oy;


    private Bitmap bitmap;

    boolean start = false;

    public void setStart(boolean start) {
        this.start = start;
    }

    public void setXm(double xm) {
        this.xm = xm;
    }

    public void setYm(double ym) {
        this.ym = ym;
    }

    public void setBitMap(Bitmap bitmap) {
        this.bitmap = bitmap;
        this.nw = this.bitmap.getWidth()/2 ;
        this.nh = this.bitmap.getHeight()/2 ;
        this.dp = Math.max(this.nw, this.nh)*2;
    }

    public void draw(Canvas canvas) {
        double xmm = this.xm - this.nw;
        double ymm = this.ym - this.nh;
        double dx = xmm - this.px;
        double dy = ymm - this.py;
        double d = Math.sqrt(dx * dx + dy * dy);
        px += ((this.ox - this.px) * .2);
        py += ((this.oy - this.py) * .2);
        if (d < dp && d > 0) {
            px = xmm - (dp * (xmm - px) / d);
            py = ymm - (dp * (ymm - py) / d);
        }
        if (start == false) {
            canvas.drawBitmap(this.bitmap, (int) Math.round(this.ox), (int) Math.round(this.oy), null);
        } else {
            canvas.drawBitmap(this.bitmap, (int) Math.round(this.px), (int) Math.round(this.py), null);
        }
    }

    public void adjustSize(int width, int height) {
        this.ox = width / 2 - this.nw;
        this.oy = height / 2 - this.nh;
    }

}
